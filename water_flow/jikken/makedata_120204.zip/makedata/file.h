#ifndef _FILE_H_
#define _FILE_H_

FILE* FILEOPEN(char* fpath, char* mode);

#endif // _FILE_H_
